# artifactory_nginx_ssl
The artifactory_nginx_ssl role installs and configures nginx for SSL.

## Role Variables
* _server_name_: This is the server name. eg. "artifactory.54.175.51.178.xip.io"
* _certificate_: This is the SSL cert.
* _certificate_key_: This is the SSL private key.
